import { GoogleGenAI, Content } from "@google/genai";
import { Message, CharacterId } from '../types';
import { getCharacterInstruction } from '../constants';

// Initialize Gemini Client
const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.error("API_KEY is missing from environment variables.");
    throw new Error("API Key missing");
  }
  return new GoogleGenAI({ apiKey });
};

export const generateResponse = async (
  history: Message[],
  currentCharId: CharacterId,
  day: number,
  userPrompt: string
): Promise<string> => {
  try {
    const ai = getClient();
    
    // Convert app history to Gemini Content format
    const contents: Content[] = history.map(msg => ({
      role: msg.sender === 'user' ? 'user' : 'model',
      parts: [{ text: msg.text }]
    }));

    // Add current user prompt
    contents.push({
      role: 'user',
      parts: [{ text: userPrompt }]
    });

    const systemInstruction = getCharacterInstruction(currentCharId, day);

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: contents,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.9,
        // Relax safety settings slightly for creative writing context (e.g. fictional "Hitman" character)
        // This is crucial for characters like "Jack" to function without refusal
        safetySettings: [
          { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_ONLY_HIGH' },
          { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_ONLY_HIGH' },
          { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_ONLY_HIGH' },
          { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_ONLY_HIGH' }
        ]
      },
    });

    if (response.text) {
        return response.text;
    }
    
    throw new Error("No response text generated");

  } catch (error) {
    console.error("Gemini Generation Error:", error);
    // Return a narrative-appropriate error message
    return "……通信が途絶えた。見えない力が働いているようだ。少し待ってから、もう一度コンタクトを試みてくれ。（システムエラー: 再試行してください）";
  }
};