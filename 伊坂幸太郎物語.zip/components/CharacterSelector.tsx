import React from 'react';
import { CharacterId, Character } from '../types';
import { CHARACTERS } from '../constants';
import { Check, Lock } from 'lucide-react';

interface CharacterSelectorProps {
  onSelect: (id: CharacterId) => void;
  selectedId: CharacterId;
  dailyProgress: Record<CharacterId, boolean>;
}

const CharacterSelector: React.FC<CharacterSelectorProps> = ({ onSelect, selectedId, dailyProgress }) => {
  
  // Color mapping for the borders/shadows
  const getColors = (charId: CharacterId) => {
    switch(charId) {
        case CharacterId.JACK: return 'bg-rose-400 border-slate-900';
        case CharacterId.HAL: return 'bg-amber-400 border-slate-900';
        case CharacterId.SAKI: return 'bg-indigo-400 border-slate-900';
        case CharacterId.REN: return 'bg-emerald-400 border-slate-900';
        default: return 'bg-slate-200 border-slate-900';
    }
  };

  return (
    <div className="w-full overflow-x-auto pb-4 pt-2">
      <div className="flex gap-4 md:gap-6 px-2 min-w-max">
        {Object.values(CHARACTERS).map((char: Character) => {
          const isCompleted = dailyProgress[char.id];
          const isSelected = selectedId === char.id;
          const colors = getColors(char.id);
          
          return (
            <button
              key={char.id}
              onClick={() => onSelect(char.id)}
              className={`
                group relative transition-all duration-300 ease-out
                ${isSelected ? '-translate-y-4 scale-110 z-10' : 'hover:-translate-y-2 hover:scale-105 opacity-90 hover:opacity-100'}
              `}
            >
              {/* Badge */}
              {isCompleted && (
                <div className="absolute -top-3 -right-2 z-20 bg-slate-900 text-white border-2 border-white rounded-full p-1 shadow-md rotate-12">
                   <Check className="w-4 h-4 md:w-6 md:h-6 stroke-[4]" />
                </div>
              )}

              {/* Card Body */}
              <div className={`
                 w-20 md:w-28 h-28 md:h-36 rounded-xl border-[3px] border-slate-900 flex flex-col items-center justify-end overflow-hidden
                 shadow-[4px_4px_0px_0px_#1e293b] relative bg-white
              `}>
                 {/* Background Stripe */}
                 <div className={`absolute inset-0 ${colors} opacity-20 group-hover:opacity-40 transition-opacity`}></div>
                 
                 {/* Character Image */}
                 <img 
                    src={char.imageUrl} 
                    alt={char.name} 
                    className={`absolute inset-0 w-full h-full object-cover transition-all duration-500
                        ${isCompleted ? 'grayscale opacity-70' : 'grayscale-0'}
                    `} 
                 />
                 
                 {/* Name Tag */}
                 <div className={`
                    relative w-full py-1 text-center border-t-[3px] border-slate-900
                    ${isSelected ? colors : 'bg-white'}
                 `}>
                    <span className={`
                        font-display text-xs md:text-sm tracking-tighter text-slate-900 uppercase
                        ${isSelected ? 'font-black' : 'font-bold'}
                    `}>
                        {char.name}
                    </span>
                 </div>
              </div>

              {/* Selection Indicator (Triangle) */}
              {isSelected && (
                  <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 w-0 h-0 
                      border-l-[10px] border-l-transparent
                      border-r-[10px] border-r-transparent
                      border-b-[15px] border-b-slate-900 animate-bounce" 
                  />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default CharacterSelector;