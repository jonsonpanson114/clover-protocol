import React from 'react';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer } from 'recharts';
import { UserStats } from '../types';

interface StatsRadarProps {
  stats: UserStats;
}

const StatsRadar: React.FC<StatsRadarProps> = ({ stats }) => {
  const data = [
    { subject: '優しさ', A: stats.kindness, fullMark: 100 },
    { subject: '楽しさ', A: stats.fun, fullMark: 100 },
    { subject: '言語化', A: stats.articulation, fullMark: 100 },
    { subject: '記憶力', A: stats.memory, fullMark: 100 },
  ];

  return (
    <div className="w-full h-full relative p-2 bg-white rounded-xl border-2 border-slate-900">
      <div className="absolute top-0 left-0 bg-slate-900 text-white text-[10px] font-bold px-2 py-0.5">STATS</div>
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart cx="50%" cy="54%" outerRadius="65%" data={data}>
          <PolarGrid stroke="#1e293b" strokeWidth={1} strokeDasharray="4 4" />
          <PolarAngleAxis 
            dataKey="subject" 
            tick={{ fill: '#1e293b', fontSize: 11, fontWeight: 900, fontFamily: 'Zen Kaku Gothic New' }} 
          />
          <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
          <Radar
            name="My Stats"
            dataKey="A"
            stroke="#1e293b"
            strokeWidth={3}
            fill="#fbbf24"
            fillOpacity={0.8}
          />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default StatsRadar;