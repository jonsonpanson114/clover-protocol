import React, { useState, useEffect, useRef } from 'react';
import { UserStats, Message, CharacterId, MissionLogEntry } from './types';
import { CHARACTERS } from './constants';
import StatsRadar from './components/StatsRadar';
import CharacterSelector from './components/CharacterSelector';
import { generateResponse } from './services/geminiService';
import { Send, Zap, Loader2, Star, AlertTriangle, Trash2, MessageCircle, Trophy, Bell, Archive, X, Menu, Calendar } from 'lucide-react';

// Updated storage key for V2 data structure
const STORAGE_KEY = 'CLOVER_PROTOCOL_STATE_V2';
const REMINDER_STORAGE_KEY = 'CLOVER_LAST_REMINDED_DATE';

type Histories = Record<CharacterId, Message[]>;

const App: React.FC = () => {
  // --- State Management ---
  const loadState = <T,>(key: string, fallback: T): T => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return parsed[key] !== undefined ? parsed[key] : fallback;
      }
    } catch (e) {
      console.error("Failed to load state", e);
    }
    return fallback;
  };

  const [day, setDay] = useState<number>(() => loadState('day', 1));
  const [stats, setStats] = useState<UserStats>(() => loadState('stats', {
    kindness: 20,
    fun: 20,
    memory: 20,
    articulation: 20,
  }));

  const initialDailyProgress = {
    [CharacterId.JACK]: false,
    [CharacterId.HAL]: false,
    [CharacterId.SAKI]: false,
    [CharacterId.REN]: false,
  };
  const [dailyProgress, setDailyProgress] = useState<Record<CharacterId, boolean>>(() => loadState('dailyProgress', initialDailyProgress));
  const [histories, setHistories] = useState<Histories>(() => loadState('histories', {
    [CharacterId.JACK]: [], [CharacterId.HAL]: [], [CharacterId.SAKI]: [], [CharacterId.REN]: [],
  }));
  const [missionLogs, setMissionLogs] = useState<MissionLogEntry[]>(() => loadState('missionLogs', []));
  const [currentCharacterId, setCurrentCharacterId] = useState<CharacterId>(() => loadState('currentCharacterId', CharacterId.JACK));
  
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showLogModal, setShowLogModal] = useState(false);
  const [showMenu, setShowMenu] = useState(false); // Mobile Menu Toggle
  const [error, setError] = useState<string | null>(null);
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>(
    typeof Notification !== 'undefined' ? Notification.permission : 'default'
  );

  const scrollRef = useRef<HTMLDivElement>(null);
  const isSendingRef = useRef(false);

  const currentHistory = histories[currentCharacterId] || [];
  const currentCharacter = CHARACTERS[currentCharacterId];
  const completedCount = Object.values(dailyProgress).filter(Boolean).length;
  const totalMissions = 4;

  // --- Effects ---
  useEffect(() => {
    try {
      const stateToSave = { day, stats, histories, missionLogs, currentCharacterId, dailyProgress };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(stateToSave));
    } catch (e) { console.error("Failed to save state", e); }
  }, [day, stats, histories, missionLogs, currentCharacterId, dailyProgress]);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [histories, currentCharacterId, isLoading]);

  useEffect(() => {
    setInputText('');
    setError(null);
  }, [currentCharacterId]);

  // --- Logic ---
  const findMissionTitle = (history: Message[], currentDay: number): string => {
    const regex = new RegExp(`\\*\\*【Day ${currentDay}: (.+?)】\\*\\*`);
    for (let i = history.length - 1; i >= 0; i--) {
      const match = history[i].text.match(regex);
      if (match && match[1]) return match[1];
    }
    return "Secret Mission";
  };

  const handleSendMessage = async (text: string = inputText) => {
    if (!text.trim() || isLoading || isSendingRef.current) return;
    isSendingRef.current = true;
    setError(null);
    
    const userMessage: Message = { id: Date.now().toString(), sender: 'user', text: text, timestamp: Date.now() };

    setHistories((prev) => ({ ...prev, [currentCharacterId]: [...(prev[currentCharacterId] || []), userMessage] }));
    setInputText('');
    setIsLoading(true);

    try {
      const contextHistory = histories[currentCharacterId] || [];
      const historyForAI = [...contextHistory, userMessage];
      const responseText = await generateResponse(historyForAI, currentCharacterId, day, text);

      let cleanedText = responseText;
      if (responseText.includes('[MISSION_COMPLETE]')) {
        cleanedText = responseText.replace('[MISSION_COMPLETE]', '');
        const charStat = CHARACTERS[currentCharacterId].stat;
        setStats(prev => ({ ...prev, [charStat]: Math.min(prev[charStat] + 15, 100) }));
        setDailyProgress(prev => ({ ...prev, [currentCharacterId]: true }));
        
        const existingTitle = findMissionTitle(historyForAI, day);
        const newLog: MissionLogEntry = {
            id: Date.now().toString(), day, characterId: currentCharacterId, title: existingTitle, completedAt: Date.now()
        };
        setMissionLogs(prev => {
            if (prev.some(log => log.day === day && log.characterId === currentCharacterId)) return prev;
            return [...prev, newLog];
        });

        // Day Clear Check
        const nextProgress = { ...dailyProgress, [currentCharacterId]: true };
        if (Object.values(nextProgress).every(Boolean)) {
             setTimeout(() => {
                alert(`CONGRATULATIONS!\nDay ${day} Cleared!\nNext Level Unlocked.`);
                setDay(d => d + 1);
                setDailyProgress(initialDailyProgress);
             }, 2000);
        }
      }

      setHistories((prev) => ({
        ...prev, [currentCharacterId]: [...(prev[currentCharacterId] || []), {
          id: (Date.now() + 1).toString(), sender: 'ai', characterId: currentCharacterId, text: cleanedText, timestamp: Date.now()
        }]
      }));
    } catch (err) {
      setError("Network Glitch. Try again.");
    } finally {
      setIsLoading(false);
      setTimeout(() => { isSendingRef.current = false; }, 100);
    }
  };

  const handleStartMission = () => {
    if (dailyProgress[currentCharacterId]) {
        handleSendMessage("今日のノルマは達成済みだが、何か？");
    } else {
        handleSendMessage("今日のミッションを頼む");
    }
  };

  const handleResetData = () => {
    if (window.confirm("WARNING: 全データを初期化しますか？")) {
      localStorage.removeItem(STORAGE_KEY);
      localStorage.removeItem(REMINDER_STORAGE_KEY);
      window.location.reload();
    }
  };

  // --- Render ---
  const renderMessageText = (text: string) => {
    return text.split('\n').map((line, i) => {
      if (line.trim().startsWith('**[') && line.trim().endsWith(']**')) {
        return <h3 key={i} className="text-pink-500 font-display text-lg mt-4 mb-2 -rotate-1 transform inline-block bg-white border-2 border-black px-2 shadow-[2px_2px_0_0_#000]">{line.replace(/\*\*/g, '')}</h3>;
      }
      if (line.trim().startsWith('**【') && line.trim().endsWith('】**')) {
         return <div key={i} className="bg-yellow-300 border-2 border-black p-2 my-4 shadow-[4px_4px_0_0_#000]"><h2 className="text-lg font-black text-slate-900">{line.replace(/\*\*/g, '')}</h2></div>;
      }
      if (line.trim().startsWith('・')) {
          return <li key={i} className="ml-4 text-slate-800 font-bold list-disc my-1">{line.replace('・','')}</li>;
      }
      if (line.trim() === '---') {
          return <hr key={i} className="border-t-2 border-dashed border-slate-300 my-4" />;
      }
      return <p key={i} className="mb-2 leading-relaxed text-slate-800 font-medium">{line}</p>;
    });
  };

  // Determine dynamic colors based on character
  const getCharTheme = (id: CharacterId) => {
      switch(id) {
          case CharacterId.JACK: return { bg: 'bg-rose-50', accent: 'text-rose-500', border: 'border-rose-400' };
          case CharacterId.HAL: return { bg: 'bg-amber-50', accent: 'text-amber-600', border: 'border-amber-400' };
          case CharacterId.SAKI: return { bg: 'bg-indigo-50', accent: 'text-indigo-600', border: 'border-indigo-400' };
          case CharacterId.REN: return { bg: 'bg-emerald-50', accent: 'text-emerald-600', border: 'border-emerald-400' };
          default: return { bg: 'bg-white', accent: 'text-black', border: 'border-black' };
      }
  }
  const theme = getCharTheme(currentCharacterId);

  return (
    <div className="min-h-screen flex flex-col md:flex-row md:h-screen overflow-hidden relative">
      
      {/* --- Overlay Menu (Mobile) --- */}
      {showMenu && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white border-4 border-black shadow-[8px_8px_0_0_#f43f5e] w-full max-w-sm p-6 flex flex-col gap-4 animate-in zoom-in-95">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="font-display text-2xl">MENU</h2>
                    <button onClick={() => setShowMenu(false)}><X className="w-8 h-8 border-2 border-black bg-white hover:bg-slate-100" /></button>
                </div>
                <button onClick={() => {setShowLogModal(true); setShowMenu(false);}} className="neo-btn bg-cyan-300 p-4 flex items-center gap-2 text-lg">
                    <Archive /> Mission Archives
                </button>
                <button onClick={handleResetData} className="neo-btn bg-slate-200 hover:bg-red-400 p-4 flex items-center gap-2 text-lg">
                    <Trash2 /> Reset Data
                </button>
                <div className="mt-4 border-t-2 border-black pt-4">
                     <p className="text-xs font-bold text-center">CLOVER PROTOCOL V3.1</p>
                </div>
            </div>
        </div>
      )}

      {/* --- Left Panel: The Agent Card --- */}
      <section className="w-full md:w-5/12 lg:w-4/12 flex flex-col relative z-10 bg-white md:border-r-4 md:border-black">
         {/* Header Bar */}
         <div className="h-16 border-b-4 border-black bg-slate-900 text-white flex items-center justify-between px-4 shrink-0">
             <div className="flex items-center gap-2">
                 <div className="w-8 h-8 bg-yellow-400 border-2 border-white text-black flex items-center justify-center font-black rounded-full animate-spin-slow">C</div>
                 <h1 className="font-display text-xl tracking-tighter">CLOVER <span className="text-yellow-400">PROTOCOL</span></h1>
             </div>
             <button onClick={() => setShowMenu(!showMenu)} className="md:hidden p-2 bg-white text-black border-2 border-black neo-btn">
                 <Menu className="w-5 h-5" />
             </button>
         </div>

         {/* Agent Visual Area */}
         <div className="flex-1 relative overflow-hidden bg-slate-100 p-4 flex flex-col">
             {/* Background decoration */}
             <div className="absolute inset-0 opacity-10" style={{backgroundImage: 'radial-gradient(#000 2px, transparent 2px)', backgroundSize: '20px 20px'}}></div>
             
             {/* Top Info Strip */}
             <div className="flex justify-between items-start mb-4 relative z-10">
                 <div className="neo-box px-3 py-1 bg-white">
                     <span className="text-xs font-bold text-slate-500">DAY</span>
                     <span className="text-2xl font-black block leading-none">{day.toString().padStart(2, '0')}</span>
                 </div>
                 <div className="neo-box px-3 py-1 bg-white flex flex-col items-end">
                     <span className="text-xs font-bold text-slate-500">PROGRESS</span>
                     <span className="text-lg font-black block leading-none text-emerald-600">{completedCount} / {totalMissions}</span>
                 </div>
             </div>

             {/* Main Character Image Card */}
             <div className="flex-1 flex flex-col items-center justify-center relative z-10 min-h-[250px]">
                 <div className={`relative w-64 h-80 border-4 border-black bg-white shadow-[8px_8px_0_0_rgba(0,0,0,1)] transition-transform duration-500 hover:rotate-1`}>
                     <img src={currentCharacter.imageUrl} alt={currentCharacter.name} className="w-full h-full object-cover grayscale contrast-125" />
                     <div className="absolute bottom-0 left-0 right-0 bg-yellow-400 border-t-4 border-black p-2">
                         <h2 className="font-display text-2xl text-black text-center uppercase tracking-tighter">{currentCharacter.name}</h2>
                         <p className="text-center text-xs font-bold font-mono uppercase bg-black text-white mx-4 -mb-4 py-1 border-2 border-white shadow-md relative z-20">
                             {currentCharacter.role}
                         </p>
                     </div>
                     {/* Floating Stats Widget */}
                     <div className="absolute -right-12 top-4 w-24 h-24 hidden md:block">
                         <StatsRadar stats={stats} />
                     </div>
                 </div>
             </div>

             {/* Squad Selector */}
             <div className="mt-8 relative z-20">
                 <div className="flex items-center gap-2 mb-2 pl-2">
                     <div className="w-3 h-3 bg-red-500 rounded-full animate-ping"></div>
                     <span className="text-xs font-black bg-black text-white px-2 py-0.5">SELECT AGENT</span>
                 </div>
                 <CharacterSelector selectedId={currentCharacterId} onSelect={setCurrentCharacterId} dailyProgress={dailyProgress} />
             </div>
         </div>

         {/* Desktop Footer Menu */}
         <div className="hidden md:flex p-4 border-t-4 border-black bg-slate-50 gap-2">
             <button onClick={() => setShowLogModal(true)} className="flex-1 neo-btn bg-white hover:bg-cyan-200 py-3 flex items-center justify-center gap-2 text-sm">
                 <Archive className="w-4 h-4" /> ARCHIVES
             </button>
             <button onClick={handleResetData} className="neo-btn bg-white hover:bg-rose-200 px-4 flex items-center justify-center">
                 <Trash2 className="w-4 h-4" />
             </button>
         </div>
      </section>

      {/* --- Right Panel: The Mission Terminal --- */}
      <main className="flex-1 bg-white flex flex-col relative overflow-hidden">
         {/* Background Pattern for Right Side */}
         <div className="absolute inset-0 bg-slate-50 opacity-50 pointer-events-none" 
              style={{backgroundImage: 'repeating-linear-gradient(45deg, #e2e8f0 25%, transparent 25%, transparent 50%, #e2e8f0 50%, #e2e8f0 75%, transparent 75%, transparent)', backgroundSize: '20px 20px'}}>
         </div>

         {/* Chat Header */}
         <div className="p-4 border-b-4 border-black bg-white relative z-10 flex items-center justify-between shadow-sm">
             <div className="flex items-center gap-3">
                 <div className={`w-3 h-3 rounded-full ${isLoading ? 'bg-yellow-400 animate-pulse' : 'bg-emerald-500'}`}></div>
                 <span className="font-mono font-bold text-sm tracking-widest text-slate-500">
                     CONNECTING TO: <span className="text-black bg-yellow-300 px-1">{currentCharacter.name.toUpperCase()}</span>
                 </span>
             </div>
             <div className="text-xs font-black border-2 border-black px-2 py-1 bg-slate-200">
                 SECURE LINE
             </div>
         </div>

         {/* Messages Area */}
         <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-8 relative z-10" ref={scrollRef}>
             {currentHistory.length === 0 ? (
                 <div className="h-full flex flex-col items-center justify-center opacity-80">
                     <div className="border-4 border-black p-8 bg-white shadow-[8px_8px_0_0_#fbbf24] text-center max-w-md transform rotate-2">
                         <h2 className="font-display text-3xl mb-4">READY?</h2>
                         <p className="font-bold text-slate-600 mb-6">
                             日々の退屈を破壊する準備はいいか？<br/>
                             エージェント {currentCharacter.name} が待機中。
                         </p>
                         <button 
                             onClick={handleStartMission}
                             disabled={dailyProgress[currentCharacterId]}
                             className="neo-btn bg-black text-white px-8 py-4 text-xl flex items-center gap-2 mx-auto hover:bg-slate-800 disabled:bg-slate-400"
                         >
                             {dailyProgress[currentCharacterId] ? 'MISSION CLEAR' : 'START MISSION'} <Zap className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                         </button>
                     </div>
                 </div>
             ) : (
                 currentHistory.map((msg) => (
                     <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                         <div className={`
                             max-w-[85%] md:max-w-[70%] relative group
                             ${msg.sender === 'user' ? 'mr-2' : 'ml-2'}
                         `}>
                             {/* Speech Bubble Tail */}
                             <div className={`absolute top-4 w-4 h-4 border-b-2 border-black bg-white rotate-45 
                                 ${msg.sender === 'user' ? '-right-2 border-r-2 bg-slate-900' : '-left-2 border-l-2'}
                             `}></div>

                             {/* Message Body */}
                             <div className={`
                                 border-2 border-black p-5 shadow-[4px_4px_0_0_rgba(0,0,0,0.2)]
                                 ${msg.sender === 'user' 
                                     ? 'bg-slate-900 text-white rounded-xl rounded-tr-none' 
                                     : 'bg-white text-slate-800 rounded-xl rounded-tl-none'}
                             `}>
                                 {msg.sender === 'ai' && (
                                     <div className="mb-2 flex items-center gap-2 border-b border-dashed border-slate-300 pb-1">
                                         <span className="font-black text-xs bg-black text-white px-1">{currentCharacter.name}</span>
                                         <span className="text-[10px] font-mono text-slate-400 ml-auto">
                                             {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                         </span>
                                     </div>
                                 )}
                                 <div className="font-medium text-sm md:text-base">
                                     {renderMessageText(msg.text)}
                                 </div>
                             </div>
                         </div>
                     </div>
                 ))
             )}
             
             {isLoading && (
                 <div className="flex justify-start animate-pulse">
                     <div className="bg-yellow-300 border-2 border-black px-4 py-2 rounded-full font-bold text-xs flex items-center gap-2 shadow-[2px_2px_0_0_#000]">
                         <Loader2 className="w-4 h-4 animate-spin" />
                         DECODING TRANSMISSION...
                     </div>
                 </div>
             )}
             
             {error && (
                 <div className="bg-red-100 border-2 border-red-500 text-red-600 p-4 rounded-lg font-bold text-center">
                     <AlertTriangle className="w-6 h-6 mx-auto mb-2" />
                     {error}
                 </div>
             )}
         </div>

         {/* Input Area */}
         <div className="p-4 bg-white border-t-4 border-black relative z-20">
             <div className="flex items-end gap-2 max-w-4xl mx-auto">
                 <div className="flex-1 relative">
                     <textarea
                         value={inputText}
                         onChange={(e) => setInputText(e.target.value)}
                         onKeyDown={(e) => {
                            if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
                                e.preventDefault();
                                handleSendMessage();
                            }
                         }}
                         placeholder={dailyProgress[currentCharacterId] ? "ミッション完了。雑談モード中。" : "メッセージを入力..."}
                         className="w-full neo-input bg-slate-50 p-4 min-h-[60px] max-h-[120px] resize-none rounded-lg text-slate-800 font-bold placeholder:text-slate-400 text-lg"
                         disabled={isLoading}
                     />
                 </div>
                 <button
                     onClick={() => handleSendMessage()}
                     disabled={isLoading || !inputText.trim()}
                     className="neo-btn bg-black text-white h-[60px] w-[60px] flex items-center justify-center rounded-lg hover:bg-slate-800 disabled:bg-slate-300"
                 >
                     <Send className="w-6 h-6" />
                 </button>
             </div>
         </div>
      </main>

      {/* --- Log Modal --- */}
      {showLogModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
           <div className="bg-white border-4 border-black shadow-[8px_8px_0_0_#000] w-full max-w-2xl max-h-[80vh] flex flex-col rounded-xl animate-in zoom-in-95">
              <div className="p-6 border-b-4 border-black flex justify-between items-center bg-cyan-300">
                  <h2 className="font-display text-2xl flex items-center gap-2">
                      <Archive className="w-6 h-6" /> MISSION LOGS
                  </h2>
                  <button onClick={() => setShowLogModal(false)} className="neo-btn p-2 bg-white hover:bg-red-400">
                      <X className="w-5 h-5" />
                  </button>
              </div>
              <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-white">
                  {missionLogs.length === 0 ? (
                      <div className="text-center py-10 font-mono font-bold text-slate-400 border-2 border-dashed border-slate-300">
                          NO DATA FOUND
                      </div>
                  ) : (
                      missionLogs.sort((a, b) => b.day - a.day || b.completedAt - a.completedAt).map((log) => {
                          const char = CHARACTERS[log.characterId];
                          return (
                              <div key={log.id} className="neo-box p-4 flex items-center gap-4">
                                  <div className="w-16 h-16 border-2 border-black overflow-hidden bg-slate-200 shrink-0">
                                      <img src={char.imageUrl} alt={char.name} className="w-full h-full object-cover grayscale" />
                                  </div>
                                  <div className="flex-1 min-w-0">
                                      <div className="flex gap-2 mb-1">
                                          <span className="bg-black text-white text-xs font-black px-2 py-0.5">DAY {log.day}</span>
                                          <span className="bg-slate-200 text-black text-xs font-bold px-2 py-0.5">{new Date(log.completedAt).toLocaleDateString()}</span>
                                      </div>
                                      <h3 className="font-bold text-lg truncate">{log.title}</h3>
                                      <p className="text-xs font-mono text-slate-500">HANDLER: {char.name}</p>
                                  </div>
                                  <Trophy className="w-6 h-6 text-yellow-500 fill-yellow-500" />
                              </div>
                          )
                      })
                  )}
              </div>
           </div>
        </div>
      )}

    </div>
  );
};

export default App;